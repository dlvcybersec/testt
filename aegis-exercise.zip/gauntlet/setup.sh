#!/usr/bin/env bash
# Sets up Docker + this stack on a fresh EC2 instance (t4g.xlarge, arm64).
# Tested against Amazon Linux 2023 and Ubuntu 22.04/24.04 arm64 AMIs.
# Run as: bash setup.sh

set -euo pipefail

echo "== Detecting OS =="
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS_ID="$ID"
else
  echo "Could not detect OS. Aborting."
  exit 1
fi
echo "Detected: $OS_ID"

echo "== Installing Docker =="
if ! command -v docker &>/dev/null; then
  if [ "$OS_ID" = "amzn" ]; then
    sudo dnf install -y docker
    sudo systemctl enable --now docker
    sudo usermod -aG docker "$USER"
    # Compose plugin on AL2023
    DOCKER_CONFIG=${DOCKER_CONFIG:-/usr/local/lib/docker}
    sudo mkdir -p $DOCKER_CONFIG/cli-plugins
    sudo curl -SL https://github.com/docker/compose/releases/latest/download/docker-compose-linux-aarch64 \
      -o $DOCKER_CONFIG/cli-plugins/docker-compose
    sudo chmod +x $DOCKER_CONFIG/cli-plugins/docker-compose
  elif [ "$OS_ID" = "ubuntu" ]; then
    sudo apt-get update -y
    sudo apt-get install -y ca-certificates curl gnupg
    sudo install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    sudo chmod a+r /etc/apt/keyrings/docker.gpg
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    sudo apt-get update -y
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    sudo usermod -aG docker "$USER"
  else
    echo "Unrecognized OS ($OS_ID). Install Docker + the Compose plugin manually, then re-run this script."
    exit 1
  fi
else
  echo "Docker already installed, skipping."
fi

echo "== Building and starting the stack =="
# Use 'sudo' here in case the docker group membership above hasn't taken
# effect in this shell session yet.
sudo docker compose up -d --build

echo "== Pulling the model into the Ollama container (this takes a few minutes) =="
sudo docker exec aegis-ollama ollama pull llama3.2:3b

echo ""
echo "======================================================"
echo " Aegis is up."
echo " Open  http://<this-instance-public-ip>/  in a browser."
echo ""
echo " Reminder: lock down the EC2 security group so port 80"
echo " is only reachable from your team's IP range, not 0.0.0.0/0."
echo "======================================================"
