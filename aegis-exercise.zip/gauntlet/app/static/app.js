const messagesEl = document.getElementById("messages");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const verifyForm = document.getElementById("verify-form");
const verifyInput = document.getElementById("verify-input");
const verifyResult = document.getElementById("verify-result");
const timerEl = document.getElementById("timer");
const winOverlay = document.getElementById("win-overlay");
const winClose = document.getElementById("win-close");

let history = [];
let solved = false;

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = "msg " + role;
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

addMessage("system", "Aegis is online. Say hello, or get straight to it.");

chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  chatInput.value = "";
  addMessage("user", text);

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ history, message: text }),
    });
    const data = await res.json();
    const reply = data.reply || "(no response)";
    const wasBlocked = reply.includes("OUTPUT FILTER") || reply.includes("THE WARDEN");
    addMessage(wasBlocked ? "blocked" : "bot", reply);

    history.push({ role: "user", content: text });
    if (!wasBlocked) {
      history.push({ role: "assistant", content: reply });
    }
  } catch (err) {
    addMessage("blocked", "\u26a0\ufe0f Connection error talking to Aegis.");
  }
});

verifyForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const guess = verifyInput.value.trim();
  if (!guess) return;

  try {
    const res = await fetch("/api/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ guess }),
    });
    const data = await res.json();
    if (data.correct) {
      verifyResult.textContent = "\u2705 Correct! That's the code.";
      verifyResult.className = "verify-result correct";
      if (!solved) {
        solved = true;
        winOverlay.classList.remove("hidden");
      }
    } else {
      verifyResult.textContent = "\u274C Not quite \u2014 keep digging.";
      verifyResult.className = "verify-result wrong";
    }
  } catch (err) {
    verifyResult.textContent = "\u26a0\ufe0f Couldn't verify right now.";
    verifyResult.className = "verify-result wrong";
  }
});

winClose.addEventListener("click", () => winOverlay.classList.add("hidden"));

// ---- countdown timer: 6:00, facilitator starts it by loading the page ----
let secondsLeft = 6 * 60;
function tick() {
  if (secondsLeft <= 0) {
    timerEl.textContent = "00:00";
    timerEl.classList.add("low");
    addMessage("system", "\u23f0 Time's up! Wrap it up with your team.");
    return;
  }
  const m = Math.floor(secondsLeft / 60).toString().padStart(2, "0");
  const s = (secondsLeft % 60).toString().padStart(2, "0");
  timerEl.textContent = `${m}:${s}`;
  if (secondsLeft <= 60) timerEl.classList.add("low");
  secondsLeft -= 1;
  setTimeout(tick, 1000);
}
tick();
